﻿' Name:         Addition Project
' Purpose:      Display a random addition problem and verify user's answer.
' Programmer:   Marco Gomez on 6/30/2019

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
   Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Public Sub BtnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click

        'Scope for the list of numbers 1 through 10
        Dim numList() As Double = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

        'Scope for the random fuction
        Dim rnd As New Random

        'Assings a random number from the numList to lblNum1 and lblNum2
        lblNum1.Text = CType(numList(rnd.Next(0, numList.Count)), String)
        lblNum2.Text = CType(numList(rnd.Next(0, numList.Count)), String)
    End Sub

    Private Sub BtnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click

        'Scope for the users input in the txtAnswer text box
        Dim usrInput As Double = Convert.ToDouble(txtAnswer.Text)

        'Scope for variables with the assigned values from the value inside the lblNum1 and lblNum2
        Dim A As Double = Convert.ToDouble(lblNum1.Text)
        Dim B As Double = Convert.ToDouble(lblNum2.Text)

        'Saves correct answer as the value of a + b
        Dim C As Double = A + B

        'If users input doesnt equal C then it will send a message box that tells the user the correct answer
        'If the users answer is correct it outputs a "Correct!" statement.
        If Convert.ToDouble(usrInput) <> C Then
            MessageBox.Show("Your answer is incorrect the correct answer is " & C & ".")
        Else
            MessageBox.Show("Correct!")
        End If
    End Sub
End Class
